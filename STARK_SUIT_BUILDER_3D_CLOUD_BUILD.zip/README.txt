STARK SUIT BUILDER 3D — Android Studio project

WHAT IS INCLUDED
- app/src/main/assets/index.html: the 3D suit builder.
- Android WebView wrapper project for Android 6.0+ (min SDK 23).
- Three.js is loaded from jsDelivr CDN, so the phone needs internet to load the 3D engine on first run / each launch.

BUILD AN APK
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync and install the Android SDK requested by Android Studio.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio shows the APK location, usually app/build/outputs/apk/debug/app-debug.apk.
6. Copy the APK to your Android phone and install it. Android may ask permission to install apps from that file manager.

NOTES
- This is an original, procedural 3D armour concept inspired by superhero suit-building games; it does not contain official movie 3D models.
- This project is source code, not a prebuilt/signed APK. A build environment is needed to compile the APK.
- The 3D preview and saved designs require WebGL support. Saved coins/designs are stored locally on the device.
