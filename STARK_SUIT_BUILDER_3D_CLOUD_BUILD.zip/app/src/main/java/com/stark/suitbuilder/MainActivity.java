package com.stark.suitbuilder;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.view.WindowManager;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
  WebView w = new WebView(this);
  WebSettings s = w.getSettings();
  s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
  w.setWebChromeClient(new WebChromeClient()); w.setWebViewClient(new WebViewClient());
  setContentView(w); w.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed() { setResult(RESULT_CANCELED); super.onBackPressed(); }
}
